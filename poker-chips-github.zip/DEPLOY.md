# Publish to GitHub and Render

Repository: [AkhilKarthik143/poker-chips](https://github.com/AkhilKarthik143/poker-chips). The repository is public.

## 1. Get the source

```sh
git clone https://github.com/AkhilKarthik143/poker-chips.git
cd poker-chips
npm ci
npm run lint && npm test
```

## 2. Apply the Render Blueprint

1. Open [Render](https://dashboard.render.com/) and sign in.
2. Select **New > Blueprint**.
3. Connect GitHub if needed, then select **poker-chips**.
4. Render reads `render.yaml`: one free Node service, Node 20, build `npm ci`, start `npm start`, health check `/healthz`.
5. Select **Apply** (or the equivalent deploy confirmation in the current UI).
6. Wait for **Live**, open the assigned `https://…onrender.com` address, and share that address with players.

Use the service’s assigned URL below:

```sh
read -r -p 'Render service URL (https://...onrender.com): ' TABLE_URL
curl -f "$TABLE_URL/healthz"
```

The `read -p` example above is for Bash. In Zsh use:

```sh
read 'TABLE_URL?Render service URL (https://...onrender.com): '
curl -f "$TABLE_URL/healthz"
```

A successful response is `{"ok":true}`. Create a room and join it from a second device before game night.

## Operations

- Leave Render’s assigned `PORT` alone; the server already uses it.
- Keep one instance. Room state is not shared across processes.
- Free instances sleep. Rooms disappear on restart/spin-down, and cold starts can be slow. **Wake it up before game night**, then create your room.
- For updates, commit and `git push`; the Blueprint uses the repository’s default branch.
- No secrets or environment file are required.


## Current service and pending update

Live URL: https://poker-chips-o7n9.onrender.com/
Existing Render service: `srv-daoo6p8473hc73d5nkeg` (poker-chips).
Reuse this service and repository; do not create a duplicate Blueprint.
The existing deployment returns HTTP 200 from `/healthz`. The new oval/reorder UI is **not deployed**: the local GitHub credential rejects pushes with HTTP 403, and `gh` is not installed.

Run these commands in Terminal to install GitHub CLI, authenticate with repository write access, validate, and publish:

```sh
brew install gh
gh auth login --hostname github.com --git-protocol https --web
gh auth setup-git
cd /Users/akhilsanapala/Documents/Codex/2026-09-20/i-n/outputs/poker-chips
npm run lint && npm test
git push -u origin main
```

Then open https://dashboard.render.com/web/srv-daoo6p8473hc73d5nkeg . Confirm Settings → Build & Deploy tracks `AkhilKarthik143/poker-chips`, branch `main`, with auto-deploy enabled. If no deployment starts, choose Manual Deploy → Deploy latest commit. Wait for Live and verify the deployed commit matches `git rev-parse HEAD`.

```sh
curl --fail --show-error https://poker-chips-o7n9.onrender.com/healthz
curl --fail --show-error https://poker-chips-o7n9.onrender.com/app.js | grep 'function seatOval'
```

The health response must be `{"ok":true}`; the second command confirms the new visualization code rather than only the older service's health. Refresh the app after deployment. Render's free tier sleeps after inactivity, so the first load after idle can be slow; in-memory tables disappear on restart.
